<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\rota_slot_staff;

class RotaController extends Controller
{
    public function show()
    {
        $staffs = rota_slot_staff::whereNotNull('staffid')
                                 ->where('slottype', '=', 'shift') 
                                 ->distinct()
                                 ->get(['staffid']);

 
        $total = array();
        $empid = 0;

        //Find the work details of each employee for each day of the week
        foreach( $staffs as $emp)
        {
            $staff = array();
            for($i = 0; $i < 7; $i++)
            {
                $empid = $emp->staffid;
                $day = rota_slot_staff::whereNotNull('staffid')
                                      ->where('slottype', '=', 'shift') 
                                      ->where('daynumber', $i)
                                      ->where('staffid', $empid)
                                      ->get();
                if(count($day) > 0)                
                    $staff[$i] = $day;
                else
                    $staff[$i] = array();
            }
            $total[$empid] = $staff;
        }

        // Find total work hours for each day
        $totalhours = array();
        for($i = 0; $i < 7; $i++)
        {
            $day = rota_slot_staff::whereNotNull('staffid')
                                  ->where('slottype', '=', 'shift') 
                                  ->where('daynumber', $i)
                                  ->get();
            $sum = 0;
            foreach( $day as $emp)
            {                
                $sum += $emp->workhours;
            }
            $totalhours[$i] = $sum;
        }
        $total['0'] = $totalhours;

        return view('rota_slot_staff.show')->with('total', $total);
    }
}