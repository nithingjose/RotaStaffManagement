<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rota_slot_staff extends Model
{
    protected $table = "rota_slot_staff";
}
