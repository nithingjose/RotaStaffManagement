<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rota Staff Management</title>

    <!-- CSS -->
    <!-- BOOTSTRAP -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <style>
        body { padding-top:50px; } /* add some padding to the top of our site */
        .innerTable tr>td, .innerTable th { border-right:none !important}
        #table_id tr>td {border-right:1px solid #ccc2c2 }
        #table_id tr>td {text-align:center;}
        #table_id tr>th {text-align:center;}
        .container{width:95%!important;}
    </style>
</head>
<body>
<script>
  $(document).ready( function () {
    $('.display').DataTable();
} );
  </script>
<div class="container">
      <table id="table_id" class="display" style="width:100%;">
      
      <thead>
      <tr>
              <th>Staff ID</th>
              <th>Sunday</th>
              <th>Monday</th>
              <th>Tuesday</th>
              <th>Wednesday</th>
              <th>Thursday</th>
              <th>Friday</th>
              <th>Saturday</th>
      </tr>
      </thead>
      
      <tbody>
      <tr>
      <td></td>
      <td><table class="innerTable"><th>Start Time</th><th>End Time</th></table>
      <td><table class="innerTable"><th>Start Time</th><th>End Time</th></table>
      <td><table class="innerTable"><th>Start Time</th><th>End Time</th></table>
      <td><table class="innerTable"><th>Start Time</th><th>End Time</th></table>
      <td><table class="innerTable"><th>Start Time</th><th>End Time</th></table>
      <td><table class="innerTable"><th>Start Time</th><th>End Time</th></table>
      <td><table class="innerTable"><th>Start Time</th><th>End Time</th></table>
      </tr>
      <?php
      foreach ($total as $id=>$rot)
      {
        echo "<tr>";

        if ($id == 0)
        {
          echo "<td>Total</td>";
          for($i = 0; $i < 7; $i++)
          {
            echo "<td>".$rot[$i]." hours</td>";
          }
          echo "</tr>";
          break;
        }
        echo "<td>$id</td>";

        foreach ($rot as $day)
        {
          if(count($day) != 0)
          {
            echo "<td><table class='innerTable'><tr><td>".$day[0]['starttime']."</td><td>".$day[0]['endtime']."</td></tr></table></td>";
          }  
          else 
          {
            echo "<td></td>";
          } 
        }
        echo "</tr>";
      }
      ?>
     
      </tbody>
      </table>
</div>
</body>
</html>